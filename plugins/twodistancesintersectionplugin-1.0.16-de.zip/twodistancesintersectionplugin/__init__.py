# -*- coding: utf-8 -*-
# twoDistancesIntersectionPlugin.py  -  Ein Python-Plugin, Schnittpunkt zweier Entfernungen für QGIS
#     Anfang            : 2023-07-18
#     Version           : 1.0.16
#.....Versionsdatum.....: 2024-04-01
#     der Autor         : Szymon Kędziora

def classFactory(iface):
    from .twoDistancesIntersectionPlugin import TwoDistancesIntersectionPlugin
    return TwoDistancesIntersectionPlugin(iface)


