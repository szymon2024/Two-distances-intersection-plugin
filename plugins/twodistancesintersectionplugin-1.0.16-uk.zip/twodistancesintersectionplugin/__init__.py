# -*- coding: utf-8 -*-
# twoDistancesIntersectionPlugin.py  -  Плагін Python Перетин двох відстаней для QGIS
#     почати           : 2023-07-18
#     версія           : 1.0.16
#.....дата версії......: 2024-04-01
#     автор            : Szymon Kędziora

def classFactory(iface):
    from .twoDistancesIntersectionPlugin import TwoDistancesIntersectionPlugin
    return TwoDistancesIntersectionPlugin(iface)


