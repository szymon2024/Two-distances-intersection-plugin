# -*- coding: utf-8 -*-
# twoDistancesIntersectionPlugin.py  -  Un plugin Python Intersecția la două distanțe pentru QGIS
#     ÎNCEPE             : 2023-07-18
#     versiune           : 1.0.16
#.....data versiunii.....: 2024-04-01
#     autor              : Szymon Kędziora

def classFactory(iface):
    from .twoDistancesIntersectionPlugin import TwoDistancesIntersectionPlugin
    return TwoDistancesIntersectionPlugin(iface)


