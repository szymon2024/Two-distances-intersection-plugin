# -*- coding: utf-8 -*-
# twoDistancesIntersectionPlugin.py  -  Programu-jalizi ya Python Makutano ya umbali mawili ya QGIS
#     kuanza               : 2023-07-18
#     toleo                : 1.0.16
#.....tarehe ya toleo......: 2024-04-01
#     mwandishi            : Szymon Kędziora

def classFactory(iface):
    from .twoDistancesIntersectionPlugin import TwoDistancesIntersectionPlugin
    return TwoDistancesIntersectionPlugin(iface)


