# -*- coding: utf-8 -*-
# twoDistancesIntersectionPlugin.py  -  Python įskiepis Dviejų atstumų sankirta QGIS
#     pradėti           : 2023-07-18
#     versija           : 1.0.16
#.....versijos data.....: 2024-04-01
#     autorius          : Szymon Kędziora

def classFactory(iface):
    from .twoDistancesIntersectionPlugin import TwoDistancesIntersectionPlugin
    return TwoDistancesIntersectionPlugin(iface)


