# -*- coding: utf-8 -*-
# twoDistancesIntersectionPlugin.py  -  Python Plugin Priesečník dvoch vzdialeností pre QGIS
#     začať            : 2023-07-18
#     verzia           : 1.0.16
#.....dátum verzie.....: 2024-04-01
#     autora           : Szymon Kędziora

def classFactory(iface):
    from .twoDistancesIntersectionPlugin import TwoDistancesIntersectionPlugin
    return TwoDistancesIntersectionPlugin(iface)


