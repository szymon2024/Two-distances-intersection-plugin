# -*- coding: utf-8 -*-
# twoDistancesIntersectionPlugin.py  -  Python プラグイン QGIS の 2 つの距離の交差
#     始める           : 2023-07-18
#     バージョン         : 1.0.16
#.....バージョンの日付......: 2024-04-01
#     著者            : Szymon Kędziora

def classFactory(iface):
    from .twoDistancesIntersectionPlugin import TwoDistancesIntersectionPlugin
    return TwoDistancesIntersectionPlugin(iface)


