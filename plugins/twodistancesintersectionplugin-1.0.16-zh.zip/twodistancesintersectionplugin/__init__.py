# -*- coding: utf-8 -*-
# twoDistancesIntersectionPlugin.py  -  QGIS 的 Python 外掛兩距離交集
#     開始            : 2023-07-18
#     版本           : 1.0.16
#.....版本日期..  ...: 2024-04-01
#     作者           : Szymon Kędziora

def classFactory(iface):
    from .twoDistancesIntersectionPlugin import TwoDistancesIntersectionPlugin
    return TwoDistancesIntersectionPlugin(iface)


