# -*- coding: utf-8 -*-
# twoDistancesIntersectionPlugin.py  -  En Python Plugin To distanser kryss for QGIS
#     begynne           : 2023-07-18
#     versjon           : 1.0.16
#.....versjonsdato......: 2024-04-01
#     forfatter         : Szymon Kędziora

def classFactory(iface):
    from .twoDistancesIntersectionPlugin import TwoDistancesIntersectionPlugin
    return TwoDistancesIntersectionPlugin(iface)


