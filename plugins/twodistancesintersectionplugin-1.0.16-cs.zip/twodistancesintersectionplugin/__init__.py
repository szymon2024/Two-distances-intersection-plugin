# -*- coding: utf-8 -*-
# twoDistancesIntersectionPlugin.py  -  Python Plugin Průnik dvou vzdáleností pro QGIS
#     začít           : 2023-07-18
#     verze           : 1.0.16
#.....datum verze.....: 2024-04-01
#     autor           : Szymon Kędziora

def classFactory(iface):
    from .twoDistancesIntersectionPlugin import TwoDistancesIntersectionPlugin
    return TwoDistancesIntersectionPlugin(iface)


