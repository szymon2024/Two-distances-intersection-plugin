# -*- coding: utf-8 -*-
# twoDistancesIntersectionPlugin.py  -  Python beépülő modul Két távolság metszéspontja a QGIS számára
#     kezdődik           : 2023-07-18
#     változat           : 1.0.16
#.....verzió dátuma......: 2024-04-01
#     szerző             : Szymon Kędziora

def classFactory(iface):
    from .twoDistancesIntersectionPlugin import TwoDistancesIntersectionPlugin
    return TwoDistancesIntersectionPlugin(iface)


