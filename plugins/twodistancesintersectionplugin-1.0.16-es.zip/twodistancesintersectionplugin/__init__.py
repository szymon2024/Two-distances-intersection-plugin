# -*- coding: utf-8 -*-
# twoDistancesIntersectionPlugin.py  -    Un complemento de Python Intersección de dos distancias para QGIS
#     comenzar          : 2023-07-18
#     versión           : 1.0.16
#.....fecha de versión..: 2024-04-01
#     autor             : Szymon Kędziora

def classFactory(iface):
    from .twoDistancesIntersectionPlugin import TwoDistancesIntersectionPlugin
    return TwoDistancesIntersectionPlugin(iface)


