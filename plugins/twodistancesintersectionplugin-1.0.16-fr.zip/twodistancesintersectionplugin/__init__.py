# -*- coding: utf-8 -*-
# twoDistancesIntersectionPlugin.py  -  Un plugin Python Intersection de deux distances pour QGIS
#     début             : 2023-07-18
#     version           : 1.0.16
#.....date de version...: 2024-04-01
#     auteur            : Szymon Kędziora

def classFactory(iface):
    from .twoDistancesIntersectionPlugin import TwoDistancesIntersectionPlugin
    return TwoDistancesIntersectionPlugin(iface)


