# -*- coding: utf-8 -*-
# twoDistancesIntersectionPlugin.py  -  'n Python-inprop Twee afstande kruising vir QGIS
#     begin             : 2023-07-18
#     weergawe          : 1.0.16
#.....weergawe datum....: 2024-04-01
#     skrywer           : Szymon Kędziora

def classFactory(iface):
    from .twoDistancesIntersectionPlugin import TwoDistancesIntersectionPlugin
    return TwoDistancesIntersectionPlugin(iface)


